#include "Shop.h"
#include "merchant.h"
#include "trader.h"
#include "scammer.h"
#include "Alchemist.h"
#include "Blacksmith.h"
#include <iostream>

using namespace std;

int main()
{
    srand(static_cast<unsigned int>(time(0)));

    merchant* npc;

    npc = new trader();
    npc->GenerateUI();
    delete npc;

    npc = new scammer();
    npc->GenerateUI();
    delete npc;

    npc = new Alchemist();
    npc->GenerateUI();
    delete npc;

    npc = new Blacksmith();
    npc->GenerateUI();
    delete npc;

    float playerCoins = 100.0f;
    Shop myShop; // Constructor runs automatically and displays the shop UI

    bool running = true;
    while (running) {
        cout << "\nYour Balance: \033[92m $ \033[0m" << playerCoins << "\n";
        cout << "[1] Buy Item\n";
        cout << "[2] Sell Test Item\n";
        cout << "[3] Refresh Shop (Costs $20)\n";
        cout << "[4] Display Shop UI\n";
        cout << "[5] Exit\n";
        cout << "Choose an action: ";

        int choice = 0;
        cin >> choice;

        switch (choice) {
        case 1: {
            cout << "Enter slot number to buy (1-" << 5 << "): ";
            int slot = 0;
            cin >> slot;
            myShop.buyItem(slot, playerCoins);
            break;
        }
        case 2: {
            // Create a temporary item to test the sell method
            item testItem("s", 100.0f);
            float earned = myShop.sellItem(testItem);
            playerCoins += earned;
            break;
        }
        case 3: {
            myShop.refreshShop(playerCoins);
            break;
        }
        case 4: {
            myShop.displayUI();
            break;
        }
        case 5: {
            cout << "Exiting shop test...\n";
            running = false;
            break;
        }
        default: {
            cout << "Invalid choice! Try again.\n";
            break;
        }
        }
    }


    return 0;
}