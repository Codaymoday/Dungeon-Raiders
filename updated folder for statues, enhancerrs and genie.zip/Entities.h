#pragma once
#include <iostream>
#include <string>
using namespace std;

class Entities
{
public:
    Entities();
    ~Entities();
    int hp = 0, spd = 0, CurrX = 1, CurrY = 1, CurrentLvl = 0, CurrentRoom = 0, def = 0, MaxXp = 0, XP = 0, Lvl = 1, Gems = 0, Coins = 0;
    int rewardXp = 0, rewardCoins = 0, rewardGems = 0, atk = 0;
    char Symbol = '\0';
    string Name = "None", Direction = " ";
    bool IsDefended = false, intutorial{}, TransitionNextRoom{};

    static const int MaxAttacks = 4;
    string AttackPool[MaxAttacks] = {},
        Description[MaxAttacks] = {};

    int AttackStats[MaxAttacks] = {},
        EnergyPoints[MaxAttacks] = {},
        Accuracy[MaxAttacks] = {},
        Priority[MaxAttacks] = {},
        CriticalChance[MaxAttacks] = {};

    enum class InteractionResult {
        Move,
        Dont_Move,
    };

    virtual InteractionResult Interaction(Entities*& Player, Entities*& Enemy) = 0;

    virtual void QueryName();
    virtual int GetLvl(); virtual int GetCoins(); virtual int GetGems();
    virtual int GetXp(); virtual int GetMaxXp();
    virtual void OpenInventory();
    virtual void SelectInv();
    virtual void Setname(string Name);
    virtual string GetName();
};