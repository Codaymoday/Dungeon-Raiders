#include "Entities.h"
Entities::Entities() {}
Entities::~Entities() {}
void Entities::QueryName() {}
int Entities::GetLvl() { return 0; } int Entities::GetCoins() { return 0; } int Entities::GetGems() { return 0; } int Entities::GetXp() { return 0; } int Entities::GetMaxXp() { return 0; }
string Entities::GetName() { return " "; }
void Entities::OpenInventory() {}
void Entities::SelectInv() {}
void Entities::Setname(std::string Name) {};