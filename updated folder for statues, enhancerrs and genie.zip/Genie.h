#pragma once
#include "NPCs.h"
#include <string>

class Genie : public NPCs
{
public:
	Genie();
	~Genie();

	// Loads dialogue only between [Genie] and [END] tags
	bool LoadSectionFromFile(const std::string& filename, const std::string& sectionTag);

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	void GenieTextAnimation(const std::string& text, int delayMs);
	const int TEXTSPEED = 15;

	int hpBonus;
	int atkBonus;
	int defBonus;
	int spdBonus;
};