#pragma once
#include "NPCs.h"
class DefStatue : public NPCs
{
public:
	DefStatue();
	~DefStatue();

	bool LoadSectionFromFile(const std::string& filename, const std::string& sectionTag);

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	int DefBonus = 0;
};

