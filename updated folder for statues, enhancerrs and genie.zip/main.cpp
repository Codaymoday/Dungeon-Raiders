#include <iostream>
#include <cstdlib>
#include <ctime>
#include "Barbarian.h"
#include "Wizard.h"
#include "Genie.h"
#include "AtkStatue.h"

int main() {
    // Seed the random number generator so rand() produces varied results
    srand(static_cast<unsigned int>(time(nullptr)));

    //Genie genie;

    //Barbarian barb;
    AtkStatue statue;

    // Access the variable directly
    cout << "Statue Attack Power: " << statue.atk << endl;
    return 0;
}