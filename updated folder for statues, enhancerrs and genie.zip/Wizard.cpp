#include "Wizard.h"
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>

using namespace std;

bool Wizard::LoadSectionFromFile(const string& filename, const string& sectionTag)
{
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: Could not open dialogue file: " << filename << endl;
        return false;
    }

    string line;
    bool insideTargetSection = false;

    while (getline(file, line)) {

        if (insideTargetSection && line == "[END]") {
            break;
        }

        if (line == sectionTag) {
            insideTargetSection = true;
            continue;
        }

        if (insideTargetSection) {

            // Read Wizard stat changes
            if (line.rfind("HP:", 0) == 0) {
                stringstream ss(line.substr(3));
                ss >> hp;
            }
            else if (line.rfind("ATK:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> atk;
            }
            else if (line.rfind("DEF:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> def;
            }
            else if (line != "---") {
                cout << line << endl;
            }
        }
    }

    file.close();
    return insideTargetSection;
}

Wizard::Wizard()
{
    hasGivenBuff = false;
    LoadSectionFromFile("npcdata.txt", "[Wizard]");
}

Wizard::~Wizard()
{}

Entities::InteractionResult Wizard::Interaction(Entities*& Player, Entities*& Enemy)
{
    if (Player != nullptr) {

        if (!hasGivenBuff) {

            Player->hp += this->hp;
            Player->atk += this->atk;
            Player->def += this->def;

            hasGivenBuff = true;
        }
    }

    return Entities::InteractionResult::Dont_Move;
}