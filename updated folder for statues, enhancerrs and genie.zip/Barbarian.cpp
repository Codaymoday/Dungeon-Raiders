#include "Barbarian.h"
#include <string>
#include <chrono>
#include <thread>
#include <fstream>
#include <iostream>
#include <sstream>

using namespace std;

void Barbarian::BarbarianTextAnimation(const string& text, int delayMs)
{
	for (char c : text) {
		cout << c << flush;
		this_thread::sleep_for(chrono::milliseconds(delayMs));
	}
	cout << "\n";
}

bool Barbarian::LoadSectionFromFile(const string& filename, const string& sectionTag)
{
	ifstream file(filename);

	if (!file.is_open()) {
		cerr << "Error: Could not open dialogue file: " << filename << endl;
		return false;
	}

	string line;
	bool insideTargetSection = false;

	while (getline(file, line)) {
		if (insideTargetSection && line == "[END]") {
			break;
		}

		if (line == sectionTag) {
			insideTargetSection = true;
			continue;
		}

		if (insideTargetSection) {
			// Read buff values into variables
			if (line.rfind("HP:", 0) == 0) {
				stringstream ss(line.substr(3));
				ss >> hp;
			}
			else if (line.rfind("ATK:", 0) == 0) {
				stringstream ss(line.substr(4));
				ss >> atk;
			}
			else if (line.rfind("DEF:", 0) == 0) {
				stringstream ss(line.substr(4));
				ss >> def;
			}
			else if (line != "---") {
				// Animated printing for dialogue lines
				BarbarianTextAnimation(line, TEXTSPEED);
			}
		}
	}

	file.close();
	return insideTargetSection;
}

Barbarian::Barbarian()
{
	// Read initial stat buff amounts from file on creation
	LoadSectionFromFile("npcdata.txt", "[Barbarian]");
}

Barbarian::~Barbarian()
{}

Entities::InteractionResult Barbarian::Interaction(Entities*& Player, Entities*& Enemy) {
	if (Player != nullptr) {

		// FIRST INTERACTION: Load dialogue from [Barbarian] section and give stats
		if (!hasGivenBuff) {
			LoadSectionFromFile("npcdata.txt", "[Barbarian]");

			// Add loaded buff stats to player
			Player->hp += this->hp;
			Player->atk += this->atk;
			Player->def += this->def;

			hasGivenBuff = true;
		}
		// REPEAT INTERACTION: Load dialogue from [Barbarian_Done] section
		else {
			LoadSectionFromFile("npcdata.txt", "[Barbarian_Done]");
		}
	}

	return Entities::InteractionResult::Dont_Move;
}