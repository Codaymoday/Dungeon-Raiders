#pragma once
#include "NPCs.h"
class AtkStatue : public NPCs
{
public:
	AtkStatue();
	~AtkStatue();

	bool LoadSectionFromFile(const std::string& filename, const std::string& sectionTag);

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	int AtkBonus = 0;
};