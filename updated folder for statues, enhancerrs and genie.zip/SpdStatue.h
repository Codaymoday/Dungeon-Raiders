#pragma once
#include "NPCs.h"
class SpdStatue : public NPCs
{
public:
	SpdStatue();
	~SpdStatue();

	bool LoadSectionFromFile(const std::string& filename, const std::string& sectionTag);

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	int SpdBonus = 0;
};

