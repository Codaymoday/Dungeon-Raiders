#include "Genie.h"
#include <string>
#include <chrono>
#include <thread>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

void Genie::GenieTextAnimation(const string& text, int delayMs)
{
	for (char c : text) {
		cout << c << flush;
		this_thread::sleep_for(chrono::milliseconds(delayMs));
	}
	cout << "\n";
}

bool Genie::LoadSectionFromFile(const string& filename, const string& sectionTag)
{
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: Could not open dialogue file: " << filename << endl;
        return false;
    }

    string line;
    bool insideTargetSection = false;

    while (getline(file, line)) {

        if (insideTargetSection && line == "[END]") {
            break;
        }

        if (line == sectionTag) {
            insideTargetSection = true;
            continue;
        }

        if (insideTargetSection) {

            // Skip completely empty lines so they don't print extra blank lines
            if (line.empty()) {
                continue;
            }

            if (line.rfind("HP:", 0) == 0) {
                stringstream ss(line.substr(3));
                ss >> hpBonus;
            }
            else if (line.rfind("ATK:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> atkBonus;
            }
            else if (line.rfind("DEF:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> defBonus;
            }
            else if (line.rfind("SPD:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> spdBonus;
            }
            else if (line != "---") {
                // If it's the prompt line, animate without printing a newline so cin stays on the same line
                if (line.rfind("WHAT DO YA SAY?", 0) == 0) {
                    for (char c : line) {
                        cout << c << flush;
                        this_thread::sleep_for(chrono::milliseconds(TEXTSPEED));
                    }
                    cout << " "; // Adds a space for the input cursor
                }
                else {
                    GenieTextAnimation(line, TEXTSPEED);
                }
            }
        }
    }

    file.close();
    return insideTargetSection;
}

Genie::Genie()
{
    // 1. Display dialogue text from [Genie]
    if (LoadSectionFromFile("npcdata.txt", "[Genie]")) {

        // 2. Load the stat configuration bounds from [Genie_stat_choice]
        LoadSectionFromFile("npcdata.txt", "[Genie_stat_choice]");

        int choice = 0;
        cin >> choice;

        // 3. Roll random stats based on loaded values
        switch (choice) {
        case 1:
            if (hpBonus > 0) hp += (rand() % hpBonus) + 1;
            GenieTextAnimation("Your health has increased!", TEXTSPEED);
            break;
        case 2:
            if (atkBonus > 0) atk += (rand() % atkBonus) + 1;
            GenieTextAnimation("Your Attack has increased!", TEXTSPEED);
            break;
        case 3:
            if (defBonus > 0) def += (rand() % defBonus) + 1;
            GenieTextAnimation("Your Defense has increased!", TEXTSPEED);
            break;
        case 4:
            if (spdBonus > 0) spd += (rand() % spdBonus);
            GenieTextAnimation("Your speed has increased!", TEXTSPEED);
            break;
        }
    }
}

Genie::~Genie()
{}

Entities::InteractionResult Genie::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
}