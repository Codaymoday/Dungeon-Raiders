#pragma once
#include "NPCs.h"
#include "Entities.h"
#include <string>

class Barbarian : public NPCs
{
public:
	Barbarian();
	~Barbarian();

	bool LoadSectionFromFile(const std::string& filename, const std::string& sectionTag);
	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	void BarbarianTextAnimation(const std::string& text, int delayMs);
	const int TEXTSPEED = 15;

	// Flag to track whether the buff has been granted
	bool hasGivenBuff = false;
};