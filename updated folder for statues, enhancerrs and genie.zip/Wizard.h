#pragma once
#include "NPCs.h"
class Wizard : public NPCs
{
public:
	Wizard();
	~Wizard();

	bool LoadSectionFromFile(const std::string& filename, const std::string& sectionTag);

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	bool hasGivenBuff;
};