#pragma once
#include "Entities.h"
class NPCs : public Entities
{
public:
    NPCs();
    ~NPCs();

    void Setname(string name) override;
    void QueryName() override;

    static void Interact();

    string GetName() override;

    string Name = "None";
    string NameArray[10] = { "Bob", "Tyson", "Mike", "Jackson", "Jane", "Bobby", "Mary", "Rose", "Lavander", "Karen" };
    char Symbol = '\0';

    InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;
private:

};