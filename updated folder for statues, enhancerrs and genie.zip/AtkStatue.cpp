#include "AtkStatue.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

bool AtkStatue::LoadSectionFromFile(const string& filename, const string& sectionTag)
{
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: Could not open dialogue file: " << filename << endl;
        return false;
    }

    string line;
    bool insideTargetSection = false;

    while (getline(file, line)) {
        if (insideTargetSection && line == "[END]") {
            break;
        }

        if (line == sectionTag) {
            insideTargetSection = true;
            continue;
        }

        if (insideTargetSection) {
            // Parses "ATK: 8" line
            if (line.rfind("ATK:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> AtkBonus;
            }
            // Prints dialogue lines skipping blank lines and dividers
            else if (!line.empty() && line != "---") {
                cout << line << endl;
            }
        }
    }

    file.close();
    return insideTargetSection;
}

AtkStatue::AtkStatue()
{
    // Load data from text file
    if (LoadSectionFromFile("npcdata.txt", "[AtkStatue]")) {
        atk = AtkBonus; // Dynamically assigns value read from file
    }
    else {
        atk = 8; // Fallback default if file loading fails
    }
}

AtkStatue::~AtkStatue()
{}

Entities::InteractionResult AtkStatue::Interaction(Entities*& Player, Entities*& Enemy) {
    return Entities::InteractionResult::Dont_Move;
}