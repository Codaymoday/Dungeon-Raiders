#include "SpdStatue.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

bool SpdStatue::LoadSectionFromFile(const string& filename, const string& sectionTag)
{
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: Could not open dialogue file: " << filename << endl;
        return false;
    }

    string line;
    bool insideTargetSection = false;

    while (getline(file, line)) {
        if (insideTargetSection && line == "[END]") {
            break;
        }

        if (line == sectionTag) {
            insideTargetSection = true;
            continue;
        }

        if (insideTargetSection) {
            // Parses "SPD: 8" line
            if (line.rfind("SPD:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> SpdBonus;
            }
            // Prints dialogue lines skipping blank lines and dividers
            else if (!line.empty() && line != "---") {
                cout << line << endl;
            }
        }
    }

    file.close();
    return insideTargetSection;
}

SpdStatue::SpdStatue()
{
    // Load data from text file
    if (LoadSectionFromFile("npcdata.txt", "[SpdStatue]")) {
        spd = SpdBonus; // Dynamically assigns value read from file
    }
    else {
        spd = 5; // Fallback default if file loading fails
    }
}

SpdStatue::~SpdStatue()
{}

Entities::InteractionResult SpdStatue::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};