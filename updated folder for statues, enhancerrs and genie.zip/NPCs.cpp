#include "NPCs.h"
#include"Entities.h"
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

NPCs::NPCs() {

}

string NPCs::GetName() {
    return this->Name;
}

void NPCs::QueryName() {

}

void NPCs::Setname(string name) {
    if (name == "1") {
        this->Name = "Connie";
    }
    else {
        int RandName = rand() % 10;
        this->Name = NameArray[RandName];
    }
}

void NPCs::Interact() {

}

Entities::InteractionResult NPCs::Interaction(Entities*& Player, Entities*& Enemy) {
    return InteractionResult::Dont_Move;
}

NPCs::~NPCs() {

}