#include "HpStatue.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

bool HpStatue::LoadSectionFromFile(const string& filename, const string& sectionTag)
{
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: Could not open dialogue file: " << filename << endl;
        return false;
    }

    string line;
    bool insideTargetSection = false;

    while (getline(file, line)) {
        if (insideTargetSection && line == "[END]") {
            break;
        }

        if (line == sectionTag) {
            insideTargetSection = true;
            continue;
        }

        if (insideTargetSection) {
            // Parses "HP: 8" line
            if (line.rfind("HP:", 0) == 0) {
                stringstream ss(line.substr(4));
                ss >> HpBonus;
            }
            // Prints dialogue lines skipping blank lines and dividers
            else if (!line.empty() && line != "---") {
                cout << line << endl;
            }
        }
    }

    file.close();
    return insideTargetSection;
}

HpStatue::HpStatue()
{
    // Load data from text file
    if (LoadSectionFromFile("npcdata.txt", "[HpStatue]")) {
        hp = HpBonus; // Dynamically assigns value read from file
    }
    else {
        hp = 8; // Fallback default if file loading fails
    }
}

HpStatue::~HpStatue()
{}

Entities::InteractionResult HpStatue::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};