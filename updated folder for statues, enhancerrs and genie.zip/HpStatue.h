#pragma once
#include "NPCs.h"
class HpStatue : public NPCs
{
public:
	HpStatue();
	~HpStatue();

	bool LoadSectionFromFile(const std::string& filename, const std::string& sectionTag);

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	int HpBonus = 0;
};

