#include "Genie.h"
#include <string>
#include <chrono>
#include <thread>

void Genie::GenieTextAnimation(const string& text, int delayMs)
{
	for (char c : text) {
		cout << c << flush;
		this_thread::sleep_for(chrono::milliseconds(delayMs));
	}
	cout << "\n";
}

Genie::Genie()
{
	GenieTextAnimation("=====================================\n", TEXTSPEED);
	GenieTextAnimation("HELLO, MY NAME's GENIE! MAKE A WISH?\n", TEXTSPEED);
	GenieTextAnimation("=====================================\n", TEXTSPEED);
	GenieTextAnimation("(1) Wish for vitality\n", TEXTSPEED);
	GenieTextAnimation("(2) Wish for strength\n", TEXTSPEED);
	GenieTextAnimation("(3) Wish for endurance\n", TEXTSPEED);
	GenieTextAnimation("(4) Wish for agility\n", TEXTSPEED);
	GenieTextAnimation("=====================================\n", TEXTSPEED);
	GenieTextAnimation("WHAT DO YA SAY? CHOOSE ONE: ", TEXTSPEED);

	int choice = 1;
	cin >> choice;
	
	switch (choice) {
	case 1:
		hp = (rand() % 14) + 1;
		GenieTextAnimation("Your health has increased!\n", TEXTSPEED);
		break;
	case 2:
		atk = (rand() % 10) + 1;
		GenieTextAnimation("Your Attack has increased!\n", TEXTSPEED);
		break;
	case 3:
		def = (rand() % 12) + 1;
		GenieTextAnimation("Your Defense has increased\n", TEXTSPEED);
		break;
	case 4:
		spd = (rand() % 4);
		GenieTextAnimation("Your speed has increased!\n", TEXTSPEED);
		break;
	}
}

Genie::~Genie()
{}

Entities::InteractionResult Genie::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};