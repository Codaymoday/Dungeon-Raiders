#include "Wizard.h"

Wizard::Wizard() 
{
	atk = 12;
	hp = -5;
}

Wizard::~Wizard()
{}

Entities::InteractionResult Wizard::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};