#include "DefStatue.h"

DefStatue::DefStatue()
{
	def = 8;
	cout << "You have been granted Defense!\n";
}

DefStatue::~DefStatue()
{}

Entities::InteractionResult DefStatue::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};