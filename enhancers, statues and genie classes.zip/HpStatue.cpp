#include "HpStatue.h"

HpStatue::HpStatue()
{
	hp = 8;
	cout << "You have been granted Health!\n";
}

HpStatue::~HpStatue()
{}

Entities::InteractionResult HpStatue::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};