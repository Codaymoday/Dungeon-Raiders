#include "AtkStatue.h"

AtkStatue::AtkStatue()
{
	atk = 8;
	cout << "You have been granted Attack!\n";
}

AtkStatue::~AtkStatue()
{}

Entities::InteractionResult AtkStatue::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};