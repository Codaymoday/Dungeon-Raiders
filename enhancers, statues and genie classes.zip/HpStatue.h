#pragma once
#include "NPCs.h"
class HpStatue : public NPCs
{
public:
	HpStatue();
	~HpStatue();

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;
};

