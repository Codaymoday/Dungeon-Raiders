#include "Barbarian.h"

Barbarian::Barbarian()
{
	atk = 5;
	hp = 5;
	def = 5;
}

Barbarian::~Barbarian()
{}

Entities::InteractionResult Barbarian::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};