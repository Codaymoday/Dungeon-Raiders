#pragma once
#include "NPCs.h"
class Wizard : public NPCs
{
public:
	Wizard();
	~Wizard();

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;
};

