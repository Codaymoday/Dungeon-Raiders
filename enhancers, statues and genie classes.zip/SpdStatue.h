#pragma once
#include "NPCs.h"
class SpdStatue : public NPCs
{
public:
	SpdStatue();
	~SpdStatue();

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;
};

