#pragma once
#include "NPCs.h"

class Genie : public NPCs
{
public:
	Genie();
	~Genie();

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;

private:
	void GenieTextAnimation(const string& text, int delayMs);

	const int TEXTSPEED = 15;
};

