#pragma once
#include "NPCs.h"
class DefStatue : public NPCs
{
public:
	DefStatue();
	~DefStatue();

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;
};

