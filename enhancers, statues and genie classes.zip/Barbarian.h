#pragma once
#include "NPCs.h"
#include "Entities.h"
class Barbarian : public NPCs
{
public: 
	Barbarian();
	~Barbarian();

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;
};

