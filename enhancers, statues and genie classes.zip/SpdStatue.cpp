#include "SpdStatue.h"

SpdStatue::SpdStatue()
{
	spd = 8;
	cout << "You have been granted Speed!\n";
}

SpdStatue::~SpdStatue()
{}

Entities::InteractionResult SpdStatue::Interaction(Entities*& Player, Entities*& Enemy) {
	return Entities::InteractionResult::Dont_Move;
};