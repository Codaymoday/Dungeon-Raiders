#pragma once
#include "NPCs.h"
class AtkStatue : public NPCs
{
public:
	AtkStatue();
	~AtkStatue();

	InteractionResult Interaction(Entities*& Player, Entities*& Enemy) override;
};

