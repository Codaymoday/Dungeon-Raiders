#include <iostream>
#include <string>
using namespace std;

int main() {


	//placeholder values
	int Name = 1;  
	int Level = 1;
	int xp = 0;
	int MaxXp = 100;
	int Coins = 0;
	int Gems = 0;

	string pName = "TUNG";
	int pHp = 100;
	string eName = "Goblin";
	int eHp = 50;

	struct Dummy { string Name; int hp; };
	Dummy p = { pName, pHp };
	Dummy e = { eName, eHp };
	Dummy* Player = &p;
	Dummy* Enemy = &e;

	//Main game lobby
	cout << "                                                             --------------------------------------------------------------\n";
	cout << "                                                             Name " << Name << " | Level " << Level << " [ " << xp << " / " << MaxXp << " ] \n";
	cout << "                                                             Coins " << Coins << " | Gems " << Gems << "                    \n";
	cout << "                                                             --------------------------------------------------------------\n";
	cout << "                                                                           (1) Dungeons | (2) Stats \n";
	cout << "                                                                           (3) Shop     | (4) Inventory\n";
	cout << "                                                             --------------------------------------------------------------\n";
	


	//Dungeon selection UI
	cout << "                                                             ==============================================================\n";
	cout << "                                                                                   [ DUNGEON SELECT ]                       \n";
	cout << "                                                             ==============================================================\n";
	cout << "                                                                     \033[94m  Please select a dungeon:\033[0m\n";
	cout << "                                                             --------------------------------------------------------------\n";
	cout << "                                                                                  1. Basic Dungeon\n";
	cout << "                                                                              \033[92m    2. Intermediate Dungeon\033[0m\n";
	cout << "                                                                              \033[95m    3. Advanced Dungeon\033[0m\n";
	cout << "                                                                              \033[36m    4. Elite Dungeon\033[0m\n";
	cout << "                                                                              \033[31m    5. Master Dungeon\033[0m\n";
	cout << "                                                             --------------------------------------------------------------\n";


	//Dialogue ui
	cout << "                                                                    +---------------------------------------------+\n";
	cout << "                                                                    | Bla bla bla bla bla bla                     |\n";
	cout << "                                                                    +---------------------------------------------+\n";


	//battle system ui
	cout << "                                                                 +----------------------------------------------------+\n";
	cout << "                                                                 |  " << Player->Name << " (HP: " << Player->hp << ") vs " << Enemy->Name << " (HP: " << Enemy->hp << ")                 |\n";
	cout << "                                                                 +----------------------------------------------------+\n";
	cout << "                                                                 |  What would you like to do?                        |\n";
	cout << "                                                                 |  (1) Attack  |  (2) Defend                         |\n";
	cout << "                                                                 |  (3) Items   |  (4) Run                            |\n";
	cout << "                                                                 |  (5) Information                                   |\n";
	cout << "                                                                 +----------------------------------------------------+\n";
	

	return 0;
}